package com.bignerdranch.android.pract1

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    lateinit var button : Button
    lateinit var editText: EditText
    lateinit var spinner: Spinner
    lateinit var textView: TextView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        spinner = findViewById(R.id.spinner)
        button=findViewById(R.id.ButtonСalculate)
        editText=findViewById(R.id.editText)
        textView = findViewById(R.id.result1Text)
        ArrayAdapter.createFromResource(this,R.array.apartment_array,android.R.layout.simple_spinner_item).also {
                adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
        }

        button.setOnClickListener {
            if(editText.text.isNotEmpty()){

                var sp = getSharedPreferences("UserData", Context.MODE_PRIVATE)
                sp.edit().putInt("quantity",editText.text.toString().toInt())
                sp.edit().putInt("i",spinner.selectedItemPosition)
                sp.edit().apply()

                val intent = Intent(this, MainActivity3::class.java)
                startActivity(intent)
            }
            else{
                showAlert("Пустые поля")
            }
        }

    }
    private fun showAlert(message: String){
        AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK") {
                dialog, _ -> dialog.dismiss()
        }.show()
    }
    }
