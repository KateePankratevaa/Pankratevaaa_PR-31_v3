package com.bignerdranch.android.pract1

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    lateinit var SingIn: Button
    lateinit var login: EditText
    lateinit var password: EditText
    lateinit var sp: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        SingIn=findViewById(R.id.ButtonSingIn)
        login=findViewById(R.id.Login)
        password=findViewById(R.id.Password)

        sp = getSharedPreferences("UserData", Context.MODE_PRIVATE)

        SingIn.setOnClickListener {

            var password_word=password.text.toString()
            var login_word=login.text.toString()



            if(password_word.isNotEmpty() && login_word.isNotEmpty())
            {
                var editor=sp.edit()

                /*editor.putString("passwordKey","iam")
                editor.putString("loginKey","123")
                editor.apply()*/

                var sp_Password:String=sp.getString("passwordKey","").toString()
                var sp_Login:String=sp.getString("loginKey","").toString()

                if(sp_Password=="" && sp_Login=="")
                {
                    editor.putString("passwordKey",password_word)
                    editor.putString("loginKey",login_word)
                    editor.apply()
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                }
                else
                {
                    if(sp_Password==password_word && sp_Login==login_word)
                    {
                        val intent = Intent(this, MainActivity2::class.java)
                        startActivity(intent)
                    }
                    else
                    {
                        showAlert("Неверный логин и/или пароль")
                    }
                }
            }
            else
            {
                showAlert("Введите логин и/или пароль")
            }

        }


    }
    private fun showAlert(message: String){
        AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK") {
                dialog, _ -> dialog.dismiss()
        }.show()
    }
    }