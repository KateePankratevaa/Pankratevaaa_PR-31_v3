package com.bignerdranch.android.pract1

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {
    lateinit var textView: TextView
    lateinit var button: Button
    lateinit var text: TextView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        textView=findViewById(R.id.resultText)
        button=findViewById(R.id.ButtonReturn)
        textView=findViewById(R.id.editText)

        var price:Int=1000
        var sp = getSharedPreferences("UserData", Context.MODE_PRIVATE)
        var i:Int=sp.getInt("i",0)
        var quantity:Int=sp.getInt("quantity",0)

        var result: Double=0.0
        when(i)
        {
            0->{result=price*quantity*1.4}
            1->{result=price*quantity*1.0}
            2->{result=price*quantity*0.8}
            3->{result=price*quantity*1.1}
        }
        textView.text="$result тыс.руб."

        button.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}